export const CASTLE_THRESHOLDS = [500, 1000, 1500, 2000];
export function getCastleStage(xp) {
  const total = Number.isFinite(xp) ? Math.max(0, xp) : 0;
  return CASTLE_THRESHOLDS.filter(t => total >= t).length;
}
export function mountCastle(container, basePath = './assets/') {
  if (!container) throw new Error('Falta el contenedor del castillo');
  const files = ['01_cimientos.png','02_paredes.png','03_tejados.png','04_iluminacion.png'];
  Object.assign(container.style, {position:'relative', aspectRatio:'1 / 1'});
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const images = files.map((name, i) => {
    const img = document.createElement('img');
    img.src = basePath.replace(/\/?$/, '/') + name;
    img.alt = ['Cimientos','Paredes','Tejados','Iluminación'][i];
    Object.assign(img.style, {position:'absolute', inset:'0', width:'100%',height:'100%',objectFit:'contain',opacity:'0',zIndex:String(i+1),pointerEvents:'none',transition:reduced?'none':'opacity 800ms ease'});
    container.append(img); return img;
  });
  return {
    update(xp) { const stage = getCastleStage(xp); images.forEach((img,i) => {img.style.opacity = i < stage ? '1' : '0'; img.setAttribute('aria-hidden',String(i>=stage));}); return stage; },
    destroy() {images.forEach(img=>img.remove());}
  };
}

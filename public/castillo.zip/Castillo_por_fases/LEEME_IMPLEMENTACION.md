# Castillo por fases — Hogar Co-op

## Contenido y estado
- assets/01_cimientos.png: base y murallas inferiores, versión revisada.
- assets/02_paredes.png: paredes y torres sin tejados. Incluye también mampostería inferior; es parcialmente acumulativa y oculta la primera capa.
- assets/03_tejados.png: tejados y agujas separados, versión revisada.
- assets/04_iluminacion.png: ventanas y resplandores cálidos, versión revisada.
- preview.html: visor offline, fases por XP y ajustes globales de posición/escala por capa.
- integration.js: funciones de cálculo de fase y montaje de capas, sin dependencias.

Los cuatro PNG tienen 1254 × 1254 píxeles y canal alfa real. Conservan su lienzo original; no recortarlos automáticamente. Son assets conceptuales generados, NO un kit con registro perfecto. Las revisiones mejoran la correspondencia pero los tejados y algunos focos siguen desplazados. No se ha validado el resultado en navegador; se ha comprobado la integridad de los PNG, su transparencia, referencias de archivos y sintaxis JavaScript.

## 1. Progresión
Usar XP acumulados del hogar, compartidos entre ambos usuarios, sin reinicio semanal.

| XP acumulados | Fase | Capas visibles |
| --- | --- | --- |
| 0–499 | 0: pendiente | Ninguna |
| 500–999 | 1: cimientos | 01 |
| 1000–1499 | 2: paredes | 01 + 02 |
| 1500–1999 | 3: tejados | 01 + 02 + 03 |
| 2000 o más | 4: iluminación | 01 + 02 + 03 + 04 |

Ejemplo: con 250 XP semanales, hitos en semanas 2, 4, 6 y 8. Es una configuración inicial editable, no una obligación. Seguir acumulando XP después de 2000 aunque este castillo esté completo. Los canjes de recompensas no descuentan XP de construcción.

## 2. Prueba local
Descomprimir TODO el ZIP y abrir preview.html. Pulsar los hitos o escribir XP. Elegir una capa y variar X/Y/escala para inspeccionar su encaje. Exportar ajustes JSON si se desea conservarlos. El visor no guarda XP ni ajustes automáticamente y no conecta con la app. Un ajuste global sirve para aproximar, pero NO soluciona cada tejado por separado.

## 3. Integración web
Copiar assets a una ruta pública, por ejemplo /assets/castillo/. Usar un contenedor cuadrado con position:relative. Todas las imágenes: position:absolute; inset:0; width:100%; height:100%; object-fit:contain. Mantener el mismo origen y tamaño. Orden de superposición: 01 abajo, luego 02, 03 y 04.

Importar integration.js como módulo en una aplicación servida por HTTP:

```js
import { mountCastle } from './integration.js';
const castle = mountCastle(document.querySelector('#castillo'), '/assets/castillo/');
castle.update(1250); // cimientos + paredes
// Al recibir el total actualizado de la app:
castle.update(2000); // añade tejados y luces
```

Mostrar las capas nuevas con transición de opacidad de 600–1000 ms. El usuario con movimiento reducido debe recibir cambios inmediatos. No animar cada vez que se abre una pestaña como si se hubiera conseguido un logro nuevo: guardar lastCelebratedStage por hogar y celebrar solo cuando la fase aumente.

## 4. Datos y sincronización
El visor es solo una demostración. Para una pareja con dos móviles, guardar los puntos en el backend existente de la app, no exclusivamente en localStorage.

Datos sugeridos:
- householdId: hogar compartido.
- xpTotal: total acumulado.
- weeklyAwards: weekStart, xp, awardId, createdAt.
- lastCelebratedStage: último hito celebrado.

Normalizar weekStart al lunes en Europe/Madrid. Aplicar una clave única householdId + weekStart al otorgar un premio semanal. Actualizar premio y XP en una transacción para evitar duplicados si ambos pulsan a la vez. Una corrección sustituye o revierte el premio previo; no añadirlo otra vez. La fase se deriva de xpTotal. Las llaves o monedas canjeables se gestionan aparte.

## 5. Acabado necesario antes de producción
1. Tomar 02_paredes.png como referencia geométrica.
2. En un editor por capas, colocar 01 debajo y comprobar el contorno inferior. La fase 02 ya contiene parte de esa base.
3. Separar cada tejado de 03 en una subcapa, alinear su borde inferior con el remate de su torre y ajustar escala individualmente. La aguja central requiere especial atención. No basta con desplazar todo 03.
4. Ajustar cada ventana luminosa de 04 a su hueco; moderar los halos que sobresalgan del castillo.
5. Exportar otra vez las cuatro capas sobre el MISMO lienzo 1254 × 1254, mismo origen, sin auto-crop. Comprobar las fases acumuladas 1, 1+2, 1+2+3 y 1+2+3+4.

No usar el ZIP como si las capas ya estuvieran registradas píxel a píxel. Se conserva aquí el material más reciente solicitado y un visor que permite evaluar exactamente qué falta.

## 6. Three.js (opcional)
No hace falta Three.js para cuatro PNG. Si el castillo vive dentro del mapa 3D, cargar las imágenes como texturas sRGB en cuatro planos de igual tamaño, con transparent:true, depthWrite:false y renderOrder 1–4. Mantener separación mínima de profundidad o controlar depthTest según la escena; evitar z-fighting. Usar materiales sin iluminación para conservar el color del render y animar opacity según la fase. Son capas 2D: una cámara lateral revelará que no tienen volumen; usar un billboard orientado a cámara o cámara fija.
